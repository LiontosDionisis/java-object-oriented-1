package gr.aueb.cf.TEST.interfaces;

public interface IShape {
    long getId();
}
