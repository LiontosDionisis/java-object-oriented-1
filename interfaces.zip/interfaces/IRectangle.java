package gr.aueb.cf.TEST.interfaces;

public interface IRectangle extends ITwoDimensional{
}
