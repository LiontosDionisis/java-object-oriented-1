package gr.aueb.cf.TEST.interfaces;

public interface ILine extends IShape{
}
