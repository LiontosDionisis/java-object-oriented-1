package gr.aueb.cf.TEST.interfaces;

public interface ICircle extends ITwoDimensional{
    double getDiameter();
}
