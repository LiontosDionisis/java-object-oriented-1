package gr.aueb.cf.TEST.interfaces;

public interface ITwoDimensional {
    double getArea();
    long getCircumference();
}
